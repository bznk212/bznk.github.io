import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const hashedPassword = await bcrypt.hash("ChangeMoiMaintenant123!", 10);

  await prisma.adminUser.upsert({
    where: { email: "admin@lareserve.com" },
    update: {},
    create: {
      email: "admin@lareserve.com",
      password: hashedPassword,
      name: "Administrateur",
    },
  });

  const product = await prisma.product.upsert({
    where: { slug: "manteau-cachemire-camel" },
    update: {},
    create: {
      title: "Manteau en cachemire camel",
      slug: "manteau-cachemire-camel",
      description:
        "Coupe épurée, cachemire italien 100%. Une pièce intemporelle pensée pour durer, confectionnée en série limitée.",
      price: 890.0,
      stock: 12,
      brand: "La Reserve",
      category: "Manteaux",
      isFeatured: true,
      images: {
        create: [
          { url: "/uploads/placeholder-1.jpg", position: 0 },
          { url: "/uploads/placeholder-2.jpg", position: 1 },
        ],
      },
    },
  });

  await prisma.review.create({
    data: {
      productId: product.id,
      author: "Camille D.",
      rating: 5,
      comment: "Qualité irréprochable, la coupe est parfaite.",
    },
  });

  console.log("Seed terminé.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
