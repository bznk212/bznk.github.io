"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import { X } from "lucide-react";

type ProductData = {
  id?: string;
  title: string;
  slug: string;
  description: string;
  price: number;
  stock: number;
  brand?: string;
  category?: string;
  isFeatured?: boolean;
  images: string[];
};

export default function ProductForm({ initial }: { initial?: ProductData }) {
  const router = useRouter();
  const [data, setData] = useState<ProductData>(
    initial ?? {
      title: "",
      slug: "",
      description: "",
      price: 0,
      stock: 0,
      brand: "",
      category: "",
      isFeatured: false,
      images: [],
    }
  );
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);

  async function handleFiles(files: FileList | null) {
    if (!files) return;
    setUploading(true);
    const uploaded: string[] = [];
    for (const file of Array.from(files)) {
      const formData = new FormData();
      formData.append("file", file);
      const res = await fetch("/api/upload", { method: "POST", body: formData });
      const json = await res.json();
      if (json.url) uploaded.push(json.url);
    }
    setData((d) => ({ ...d, images: [...d.images, ...uploaded] }));
    setUploading(false);
  }

  function removeImage(url: string) {
    setData((d) => ({ ...d, images: d.images.filter((i) => i !== url) }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    const method = initial?.id ? "PUT" : "POST";
    const url = initial?.id ? `/api/produits/${initial.id}` : "/api/produits";

    const res = await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });

    setSaving(false);
    if (res.ok) router.push("/admin/produits");
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6 max-w-2xl">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="eyebrow block mb-2">Titre</label>
          <input
            required
            value={data.title}
            onChange={(e) => setData({ ...data, title: e.target.value })}
            className="w-full border border-line px-4 py-2 bg-transparent text-paper focus:outline-none focus:border-brass"
          />
        </div>
        <div>
          <label className="eyebrow block mb-2">Slug (URL)</label>
          <input
            required
            value={data.slug}
            onChange={(e) => setData({ ...data, slug: e.target.value })}
            className="w-full border border-line px-4 py-2 bg-transparent text-paper focus:outline-none focus:border-brass"
          />
        </div>
      </div>

      <div>
        <label className="eyebrow block mb-2">Description</label>
        <textarea
          required
          rows={4}
          value={data.description}
          onChange={(e) => setData({ ...data, description: e.target.value })}
          className="w-full border border-line px-4 py-2 bg-transparent text-paper focus:outline-none focus:border-brass"
        />
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div>
          <label className="eyebrow block mb-2">Prix (€)</label>
          <input
            required
            type="number"
            step="0.01"
            value={data.price}
            onChange={(e) => setData({ ...data, price: Number(e.target.value) })}
            className="w-full border border-line px-4 py-2 bg-transparent text-paper focus:outline-none focus:border-brass"
          />
        </div>
        <div>
          <label className="eyebrow block mb-2">Stock</label>
          <input
            required
            type="number"
            value={data.stock}
            onChange={(e) => setData({ ...data, stock: Number(e.target.value) })}
            className="w-full border border-line px-4 py-2 bg-transparent text-paper focus:outline-none focus:border-brass"
          />
        </div>
        <div>
          <label className="eyebrow block mb-2">Catégorie</label>
          <input
            value={data.category}
            onChange={(e) => setData({ ...data, category: e.target.value })}
            className="w-full border border-line px-4 py-2 bg-transparent text-paper focus:outline-none focus:border-brass"
          />
        </div>
      </div>

      <div>
        <label className="eyebrow block mb-2">Marque</label>
        <input
          value={data.brand}
          onChange={(e) => setData({ ...data, brand: e.target.value })}
          className="w-full border border-line px-4 py-2 bg-transparent text-paper focus:outline-none focus:border-brass"
        />
      </div>

      <label className="flex items-center gap-2 text-sm">
        <input
          type="checkbox"
          checked={data.isFeatured}
          onChange={(e) => setData({ ...data, isFeatured: e.target.checked })}
        />
        Pièce rare (mise en avant sur la page d'accueil)
      </label>

      <div>
        <label className="eyebrow block mb-2">Images produit</label>
        <input type="file" multiple accept="image/*" onChange={(e) => handleFiles(e.target.files)} />
        {uploading && <p className="text-sm text-brass mt-2">Envoi en cours...</p>}
        <div className="flex gap-3 mt-4 flex-wrap">
          {data.images.map((url) => (
            <div key={url} className="relative w-20 h-24">
              <Image src={url} alt="" fill className="object-cover" />
              <button
                type="button"
                onClick={() => removeImage(url)}
                className="absolute -top-2 -right-2 bg-paper text-ink rounded-full p-0.5"
              >
                <X size={12} />
              </button>
            </div>
          ))}
        </div>
      </div>

      <button type="submit" disabled={saving || uploading} className="btn-reserve">
        {saving ? "Enregistrement..." : "Enregistrer le produit"}
      </button>
    </form>
  );
}
