"use client";

import { useRouter } from "next/navigation";

export default function DeleteProductButton({ productId }: { productId: string }) {
  const router = useRouter();

  async function handleDelete() {
    if (!confirm("Supprimer définitivement ce produit ?")) return;
    await fetch(`/api/produits/${productId}`, { method: "DELETE" });
    router.refresh();
  }

  return (
    <button onClick={handleDelete} className="underline text-danger">
      Supprimer
    </button>
  );
}
