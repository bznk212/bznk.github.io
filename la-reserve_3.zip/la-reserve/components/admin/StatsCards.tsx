export default function StatsCards({
  sales,
  expenses,
  profit,
  ordersCount,
}: {
  sales: number;
  expenses: number;
  profit: number;
  ordersCount: number;
}) {
  const cards = [
    { label: "Ventes", value: `${sales.toFixed(2)} €` },
    { label: "Dépenses", value: `${expenses.toFixed(2)} €` },
    { label: "Bénéfices", value: `${profit.toFixed(2)} €` },
    { label: "Commandes", value: String(ordersCount) },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
      {cards.map((c) => (
        <div key={c.label} className="border border-line p-6">
          <p className="eyebrow mb-2">{c.label}</p>
          <p className="font-display text-3xl">{c.value}</p>
        </div>
      ))}
    </div>
  );
}
