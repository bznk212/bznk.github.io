"use client";

import { useState } from "react";

type Order = {
  id: string;
  customerName: string;
  total: number;
  status: string;
  trackingNumber: string | null;
  carrier: string | null;
  createdAt: string;
};

export default function OrderRow({ order }: { order: Order }) {
  const [trackingNumber, setTrackingNumber] = useState(order.trackingNumber ?? "");
  const [carrier, setCarrier] = useState(order.carrier ?? "");
  const [status, setStatus] = useState(order.status);
  const [saving, setSaving] = useState(false);

  async function save() {
    setSaving(true);
    await fetch(`/api/commandes/${order.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ trackingNumber, carrier, status }),
    });
    setSaving(false);
  }

  return (
    <tr className="border-b border-line align-top">
      <td className="py-3">{order.customerName}</td>
      <td>{Number(order.total).toFixed(2)} €</td>
      <td>
        <select value={status} onChange={(e) => setStatus(e.target.value)} className="border border-line px-2 py-1 bg-transparent text-paper focus:outline-none focus:border-brass">
          {["PENDING", "PAID", "SHIPPED", "DELIVERED", "CANCELLED"].map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
      </td>
      <td>
        <input
          value={carrier}
          onChange={(e) => setCarrier(e.target.value)}
          placeholder="Code transporteur (auto si vide)"
          title="Optionnel : 17track auto-détecte la plupart des transporteurs. Code sur res.17track.net/asset/carrier/info/carrier.all.json"
          className="border border-line px-2 py-1 bg-transparent text-paper focus:outline-none focus:border-brass w-28"
        />
      </td>
      <td>
        <input
          value={trackingNumber}
          onChange={(e) => setTrackingNumber(e.target.value)}
          placeholder="N° de suivi"
          className="border border-line px-2 py-1 bg-transparent text-paper focus:outline-none focus:border-brass w-32"
        />
      </td>
      <td>
        <button onClick={save} disabled={saving} className="underline text-brass text-xs uppercase tracking-wide2">
          {saving ? "..." : "Enregistrer"}
        </button>
      </td>
    </tr>
  );
}
