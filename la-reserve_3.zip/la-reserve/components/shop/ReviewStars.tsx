"use client";

import { Star } from "lucide-react";

export default function ReviewStars({
  rating,
  size = 16,
  interactive = false,
  onChange,
}: {
  rating: number;
  size?: number;
  interactive?: boolean;
  onChange?: (value: number) => void;
}) {
  return (
    <div className="flex gap-1">
      {[1, 2, 3, 4, 5].map((n) => (
        <button
          key={n}
          type="button"
          disabled={!interactive}
          onClick={() => onChange?.(n)}
          className={interactive ? "cursor-pointer" : "cursor-default"}
          aria-label={`${n} étoile${n > 1 ? "s" : ""}`}
        >
          <Star
            size={size}
            fill={n <= rating ? "#B08D57" : "none"}
            stroke="#B08D57"
            strokeWidth={1.2}
          />
        </button>
      ))}
    </div>
  );
}
