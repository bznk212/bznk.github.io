import Link from "next/link";
import Image from "next/image";

type Props = {
  slug: string;
  title: string;
  price: number;
  image: string;
  index?: number;
  stock?: number;
};

export default function ProductCard({ slug, title, price, image, index, stock }: Props) {
  return (
    <Link href={`/produits/${slug}`} className="group block relative">
      <div className="product-image-zoom relative overflow-hidden bg-panel border border-line">
        <div className="relative aspect-[4/5]">
          <Image src={image} alt={title} fill className="object-cover" />
        </div>

        {/* Signature element : la fiche de catalogue qui glisse depuis le bas au survol */}
        <div className="ledger-tag w-full justify-between">
          <span>N° {String(index ?? 1).padStart(3, "0")}</span>
          <span>{stock === 0 ? "Épuisé" : stock !== undefined && stock <= 5 ? `${stock} restantes` : "En stock"}</span>
        </div>
      </div>

      <div className="mt-5 flex items-start justify-between gap-4">
        <div>
          <p className="font-mono text-[10px] text-brass tracking-wide2 mb-1">
            N° {String(index ?? 1).padStart(3, "0")}
          </p>
          <h3 className="font-display italic text-lg text-paper leading-tight">{title}</h3>
        </div>
        <span className="font-mono text-sm text-paper-dim whitespace-nowrap">{price.toFixed(2)} €</span>
      </div>
    </Link>
  );
}
