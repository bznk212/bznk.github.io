export default function SiteFooter() {
  return (
    <footer className="border-t border-line mt-32">
      <div className="max-w-[1400px] mx-auto px-6 md:px-16 py-16">
        <div className="flex flex-col md:flex-row justify-between gap-10 md:gap-6">
          <div>
            <p className="font-display italic text-xl text-paper mb-2">La Reserve</p>
            <p className="font-mono text-[11px] text-paper-dim tracking-wide2">
              ÉTABLI EN 2026 — REGISTRE OUVERT
            </p>
          </div>
          <div className="flex gap-12 font-mono text-[11px] uppercase tracking-wide2 text-paper-dim">
            <div className="space-y-2">
              <p className="text-brass">Registre</p>
              <p>Livraison & retours</p>
              <p>Mentions légales</p>
            </div>
            <div className="space-y-2">
              <p className="text-brass">Contact</p>
              <p>contact@lareserve.com</p>
            </div>
          </div>
        </div>
        <div className="mt-16 pt-6 border-t border-line font-mono text-[10px] text-paper-dim/60 tracking-wide2 uppercase">
          © {new Date().getFullYear()} La Reserve — Tous droits réservés
        </div>
      </div>
    </footer>
  );
}
