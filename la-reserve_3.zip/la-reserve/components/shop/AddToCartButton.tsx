"use client";

import { useState } from "react";
import { useCart } from "@/context/CartContext";

export default function AddToCartButton({
  productId,
  title,
  price,
  image,
}: {
  productId: string;
  title: string;
  price: number;
  image: string;
}) {
  const { addItem } = useCart();
  const [added, setAdded] = useState(false);

  function handleClick() {
    addItem({ productId, title, price, image });
    setAdded(true);
    setTimeout(() => setAdded(false), 1800);
  }

  return (
    <button onClick={handleClick} className="btn-reserve w-full md:w-auto">
      {added ? "Ajouté au panier" : "Ajouter au panier"}
    </button>
  );
}
