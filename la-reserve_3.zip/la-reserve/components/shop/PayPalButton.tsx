"use client";

import { PayPalScriptProvider, PayPalButtons } from "@paypal/react-paypal-js";
import { useCart } from "@/context/CartContext";
import { useRouter } from "next/navigation";

type Customer = {
  name: string;
  email: string;
  address: string;
  city: string;
  postalCode: string;
  country: string;
};

export default function PayPalButton({ customer }: { customer: Customer }) {
  const { items, clearCart } = useCart();
  const router = useRouter();

  return (
    <PayPalScriptProvider
      options={{
        clientId: process.env.NEXT_PUBLIC_PAYPAL_CLIENT_ID!,
        currency: "EUR",
        intent: "capture",
      }}
    >
      <PayPalButtons
        style={{ layout: "vertical", color: "black", shape: "rect", label: "pay" }}
        createOrder={async () => {
          const res = await fetch("/api/paypal/create-order", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              cart: items.map((i) => ({ productId: i.productId, quantity: i.quantity })),
              customer,
            }),
          });
          const data = await res.json();
          return data.paypalOrderId;
        }}
        onApprove={async (data) => {
          const res = await fetch("/api/paypal/capture-order", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ paypalOrderId: data.orderID }),
          });
          const result = await res.json();
          if (result.success) {
            clearCart();
            router.push(`/confirmation?orderId=${result.orderId}`);
          }
        }}
      />
    </PayPalScriptProvider>
  );
}
