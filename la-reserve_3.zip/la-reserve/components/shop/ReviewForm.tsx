"use client";

import { useState } from "react";
import ReviewStars from "./ReviewStars";

export default function ReviewForm({ productId }: { productId: string }) {
  const [rating, setRating] = useState(5);
  const [author, setAuthor] = useState("");
  const [comment, setComment] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "done" | "error">("idle");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setStatus("loading");
    try {
      const res = await fetch("/api/avis", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ productId, author, rating, comment }),
      });
      if (!res.ok) throw new Error();
      setStatus("done");
      setAuthor("");
      setComment("");
      setRating(5);
    } catch {
      setStatus("error");
    }
  }

  if (status === "done") {
    return <p className="text-sm text-brass">Merci, votre avis a bien été publié.</p>;
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4 max-w-md">
      <div>
        <label className="eyebrow block mb-2">Votre note</label>
        <ReviewStars rating={rating} interactive onChange={setRating} size={22} />
      </div>
      <div>
        <label className="eyebrow block mb-2">Votre nom</label>
        <input
          required
          value={author}
          onChange={(e) => setAuthor(e.target.value)}
          className="w-full border border-line px-4 py-2 bg-transparent text-paper placeholder:text-paper-dim focus:outline-none focus:border-brass"
        />
      </div>
      <div>
        <label className="eyebrow block mb-2">Votre commentaire</label>
        <textarea
          required
          rows={4}
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          className="w-full border border-line px-4 py-2 bg-transparent text-paper placeholder:text-paper-dim focus:outline-none focus:border-brass"
        />
      </div>
      <button type="submit" disabled={status === "loading"} className="btn-reserve">
        {status === "loading" ? "Envoi..." : "Publier l'avis"}
      </button>
      {status === "error" && (
        <p className="text-sm text-danger">Une erreur est survenue, réessayez.</p>
      )}
    </form>
  );
}
