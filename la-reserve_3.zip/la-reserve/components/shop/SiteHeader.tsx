"use client";

import Link from "next/link";
import { useState } from "react";
import { useCart } from "@/context/CartContext";

export default function SiteHeader() {
  const { count } = useCart();
  const [bagHover, setBagHover] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-ink/95 backdrop-blur-sm border-b border-line">
      <div className="max-w-[1400px] mx-auto px-6 md:px-16 h-20 flex items-center justify-between">
        <Link href="/" className="font-display italic text-2xl tracking-wide text-paper">
          La Reserve
        </Link>

        <nav className="hidden md:flex items-center gap-10 font-mono text-[11px] uppercase tracking-wide2 text-paper-dim">
          <Link href="/produits" className="hover:text-brass transition-colors duration-300">
            Collection
          </Link>
          <Link href="/produits?featured=true" className="hover:text-brass transition-colors duration-300">
            Pièces rares
          </Link>
          <Link href="/a-propos" className="hover:text-brass transition-colors duration-300">
            La Maison
          </Link>
        </nav>

        <Link
          href="/panier"
          onMouseEnter={() => setBagHover(true)}
          onMouseLeave={() => setBagHover(false)}
          className="relative font-mono text-[11px] uppercase tracking-wide2 text-paper-dim hover:text-brass transition-colors duration-300 flex items-center gap-2"
        >
          <span>Panier</span>
          <span className={`transition-colors duration-300 ${count > 0 ? "text-brass" : "text-paper-dim"}`}>
            [{String(count).padStart(2, "0")}]
          </span>
        </Link>
      </div>
    </header>
  );
}
