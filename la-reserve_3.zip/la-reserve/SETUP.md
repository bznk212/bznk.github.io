# La Reserve — Guide de mise en route

Ce projet est un scaffold Next.js 14 (App Router) complet et fonctionnel :
vitrine, panier, PayPal Checkout, avis clients, dashboard admin (CRUD produits,
ventes/dépenses/bénéfices, suivi de colis). Il te reste à installer les
dépendances, connecter une base de données et renseigner tes clés d'API.

## 1. Prérequis

- Node.js 18.18+ installé
- Un compte PostgreSQL (le plus simple : [Neon](https://neon.tech) ou
  [Supabase](https://supabase.com), gratuits pour démarrer)
- Un compte développeur PayPal : https://developer.paypal.com
- Un compte Cloudinary (gratuit) : https://cloudinary.com
- Un compte 17track (gratuit) : https://www.17track.net

## 2. Installation

```bash
cd la-reserve
npm install
```

## 3. Configuration des variables d'environnement

Copie `.env.example` en `.env` :

```bash
cp .env.example .env
```

Puis remplis chaque valeur :

### DATABASE_URL
Crée un projet sur Neon ou Supabase, copie la chaîne de connexion PostgreSQL
fournie (commence par `postgresql://...`).

### NEXTAUTH_SECRET
```bash
openssl rand -base64 32
```
Colle le résultat tel quel.

### PayPal (PAYPAL_CLIENT_ID / PAYPAL_CLIENT_SECRET)
1. Va sur https://developer.paypal.com/dashboard/applications
2. Crée une app en mode **Sandbox** pour tester (tu passeras en **Live** avec
   ton vrai compte PayPal marchand quand tu seras prêt à encaisser réellement).
3. Copie le Client ID et le Secret dans `.env`.
4. Mets le même Client ID dans `NEXT_PUBLIC_PAYPAL_CLIENT_ID` (celui-ci est
   exposé au navigateur, c'est normal — le Secret ne l'est jamais).
5. Pour passer en production : change `PAYPAL_ENV=live` et utilise les clés
   Live de ton compte PayPal réel. C'est ce compte qui recevra les paiements.

### Cloudinary (upload des images produits)
1. Crée un compte sur cloudinary.com
2. Dans le dashboard, copie `Cloud name`, `API Key`, `API Secret`

### 17track (suivi de colis, gratuit)
1. Crée un compte sur https://www.17track.net
2. Va dans le dashboard > Settings > API pour copier ta clé (`17token`)
3. (Optionnel mais recommandé) Configure un webhook vers
   `https://tondomaine.com/api/webhooks/track17` dans Settings > Webhook
   pour que le statut des commandes se mette à jour automatiquement.
4. Le code transporteur est optionnel : 17track détecte automatiquement plus
   de 80% des transporteurs à partir du format du numéro de suivi. Si tu veux
   forcer un transporteur précis, trouve son code ici :
   https://res.17track.net/asset/carrier/info/carrier.all.json

## 4. Base de données

```bash
npm run prisma:generate
npm run prisma:migrate
npm run seed
```

Le seed crée :
- un compte admin : `admin@lareserve.com` / `ChangeMoiMaintenant123!`
  **(change ce mot de passe immédiatement en le régénérant, voir plus bas)**
- un produit de démonstration

Pour changer le mot de passe admin, édite `prisma/seed.ts` avant de lancer
`npm run seed`, ou crée un petit script similaire pour mettre à jour le hash
en base directement.

## 5. Lancer le projet en local

```bash
npm run dev
```

- Vitrine : http://localhost:3000
- Admin : http://localhost:3000/admin/connexion

## 6. Tester un paiement PayPal (sandbox)

1. Ajoute un produit au panier, va au checkout, remplis l'adresse
2. Clique sur le bouton PayPal
3. Connecte-toi avec un compte **acheteur sandbox** (créé automatiquement par
   PayPal dans ton dashboard développeur, onglet "Sandbox > Accounts")
4. Le paiement est capturé, la commande passe en statut `PAID`

## 7. Déploiement en production

Recommandé : **Vercel** (fait pour Next.js).

1. Pousse le code sur GitHub
2. Importe le repo sur https://vercel.com/new
3. Renseigne toutes les variables d'environnement du `.env` dans les
   "Environment Variables" du projet Vercel
4. Passe `PAYPAL_ENV=live` et utilise tes clés PayPal Live
5. Mets à jour `NEXTAUTH_URL` avec ton vrai domaine
6. Déploie

Pense à relancer `npx prisma migrate deploy` (ou configurer un build step)
pour appliquer les migrations sur la base de production.

## 8. Ce qui est déjà codé

- ✅ Vitrine : accueil, catalogue, fiche produit avec carrousel
- ✅ Avis clients (étoiles + commentaires) par produit
- ✅ Panier persistant (localStorage) + tunnel de commande
- ✅ PayPal Checkout complet (création + capture de commande, paiement direct
  sur ton compte PayPal)
- ✅ Dashboard admin protégé (NextAuth) : ventes/dépenses/bénéfices, CRUD
  produits avec upload multi-images (Cloudinary), gestion des commandes avec
  suivi de colis (17track) + webhook de mise à jour automatique

## 9. Pistes d'amélioration pour la suite

- Emails transactionnels (confirmation de commande) via Resend ou Postmark
- Page dédiée pour ajouter des dépenses depuis le dashboard (l'API existe
  déjà : `POST /api/depenses`)
- Filtrage/recherche plus poussé sur le catalogue (par prix, taille, etc.)
- Gestion des tailles/variantes produit si nécessaire
- Affiner le `middleware.ts` pour ne protéger que les méthodes mutantes
  (POST/PUT/DELETE) des routes API produits/commandes, si tu veux garder
  certaines lectures publiques via ces mêmes endpoints
