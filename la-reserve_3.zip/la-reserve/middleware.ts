import { withAuth } from "next-auth/middleware";

export default withAuth({
  pages: { signIn: "/admin/connexion" },
});

export const config = {
  matcher: ["/admin/:path*", "/api/produits/:path*", "/api/commandes/:path*"],
};
// Note : les routes API produits en GET restent publiques pour la vitrine.
// Affiner ce matcher plus tard pour ne protéger que les méthodes mutantes
// (POST/PUT/DELETE) si besoin, via une vérification dans chaque route handler.
