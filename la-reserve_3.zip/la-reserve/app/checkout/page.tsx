"use client";

import { useState } from "react";
import { useCart } from "@/context/CartContext";
import PayPalButton from "@/components/shop/PayPalButton";

export default function CheckoutPage() {
  const { items, total } = useCart();
  const [customer, setCustomer] = useState({
    name: "",
    email: "",
    address: "",
    city: "",
    postalCode: "",
    country: "France",
  });
  const [confirmed, setConfirmed] = useState(false);

  const isValid = Object.values(customer).every((v) => v.trim().length > 0);

  return (
    <div className="section grid md:grid-cols-2 gap-16">
      <div>
        <h1 className="font-display italic text-3xl mb-10">Livraison</h1>
        <form className="space-y-4 max-w-md" onSubmit={(e) => e.preventDefault()}>
          {[
            { key: "name", label: "Nom complet" },
            { key: "email", label: "Email" },
            { key: "address", label: "Adresse" },
            { key: "city", label: "Ville" },
            { key: "postalCode", label: "Code postal" },
            { key: "country", label: "Pays" },
          ].map((field) => (
            <div key={field.key}>
              <label className="eyebrow block mb-2">{field.label}</label>
              <input
                required
                value={(customer as any)[field.key]}
                onChange={(e) => setCustomer({ ...customer, [field.key]: e.target.value })}
                className="w-full border border-line px-4 py-2 bg-transparent text-paper placeholder:text-paper-dim focus:outline-none focus:border-brass"
              />
            </div>
          ))}
          <button
            type="button"
            onClick={() => setConfirmed(true)}
            disabled={!isValid}
            className="btn-reserve disabled:opacity-40"
          >
            Continuer vers le paiement
          </button>
        </form>
      </div>

      <div>
        <h2 className="font-display italic text-2xl mb-8">Récapitulatif</h2>
        <div className="space-y-4 mb-8">
          {items.map((item) => (
            <div key={item.productId} className="flex justify-between text-sm">
              <span>
                {item.title} × {item.quantity}
              </span>
              <span>{(item.price * item.quantity).toFixed(2)} €</span>
            </div>
          ))}
        </div>
        <div className="flex justify-between font-display italic text-xl border-t border-line pt-4 mb-10">
          <span>Total</span>
          <span>{total.toFixed(2)} €</span>
        </div>

        {confirmed && isValid && <PayPalButton customer={customer} />}
      </div>
    </div>
  );
}
