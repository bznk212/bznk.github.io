export default function ConfirmationPage({
  searchParams,
}: {
  searchParams: { orderId?: string };
}) {
  return (
    <div className="section text-center min-h-[60vh] flex flex-col justify-center">
      <h1 className="font-display italic text-4xl mb-6">Merci pour votre commande</h1>
      <p className="text-brass">
        Un email de confirmation vous sera envoyé sous peu.
        {searchParams.orderId && (
          <>
            <br />
            Référence : {searchParams.orderId}
          </>
        )}
      </p>
    </div>
  );
}
