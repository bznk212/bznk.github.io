import { prisma } from "@/lib/prisma";
import ProductCard from "@/components/shop/ProductCard";

export default async function CatalogPage({
  searchParams,
}: {
  searchParams: { category?: string; featured?: string };
}) {
  const products = await prisma.product.findMany({
    where: {
      category: searchParams.category,
      isFeatured: searchParams.featured === "true" ? true : undefined,
    },
    include: { images: { orderBy: { position: "asc" }, take: 1 } },
    orderBy: { createdAt: "desc" },
  });

  return (
    <div className="section">
      <div className="mb-16 border-b border-line pb-6">
        <p className="eyebrow mb-3">Registre complet</p>
        <h1 className="font-display italic text-4xl text-paper">La Collection</h1>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-x-8 gap-y-16">
        {products.map((p, i) => (
          <ProductCard
            key={p.id}
            index={i + 1}
            slug={p.slug}
            title={p.title}
            price={Number(p.price)}
            image={p.images[0]?.url ?? "/uploads/placeholder-1.jpg"}
            stock={p.stock}
          />
        ))}
      </div>
      {products.length === 0 && (
        <p className="text-paper-dim font-mono text-sm">Aucune pièce ne correspond à cette sélection pour le moment.</p>
      )}
    </div>
  );
}
