import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import ProductCarousel from "@/components/shop/ProductCarousel";
import ReviewStars from "@/components/shop/ReviewStars";
import ReviewForm from "@/components/shop/ReviewForm";
import AddToCartButton from "@/components/shop/AddToCartButton";

export default async function ProductPage({ params }: { params: { slug: string } }) {
  const product = await prisma.product.findUnique({
    where: { slug: params.slug },
    include: {
      images: { orderBy: { position: "asc" } },
      reviews: { orderBy: { createdAt: "desc" } },
    },
  });

  if (!product) notFound();

  const avgRating =
    product.reviews.length > 0
      ? product.reviews.reduce((s, r) => s + r.rating, 0) / product.reviews.length
      : 0;

  return (
    <div className="section grid md:grid-cols-2 gap-16">
      <ProductCarousel images={product.images} />

      <div>
        <p className="eyebrow mb-3">
          {product.brand ? `${product.brand} — ` : ""}Réf. {product.id.slice(-6).toUpperCase()}
        </p>
        <h1 className="font-display italic text-4xl mb-4 text-paper">{product.title}</h1>

        <div className="flex items-center gap-3 mb-6">
          <ReviewStars rating={Math.round(avgRating)} />
          <span className="font-mono text-xs text-paper-dim">
            {product.reviews.length} avis {product.reviews.length > 0 && `· ${avgRating.toFixed(1)}/5`}
          </span>
        </div>

        <p className="font-mono text-xl mb-8 text-paper">{Number(product.price).toFixed(2)} €</p>
        <p className="leading-relaxed text-paper/80 mb-10">{product.description}</p>

        <AddToCartButton
          productId={product.id}
          title={product.title}
          price={Number(product.price)}
          image={product.images[0]?.url ?? ""}
        />

        {product.stock <= 5 && product.stock > 0 && (
          <p className="mt-4 font-mono text-xs text-brass">Plus que {product.stock} pièces disponibles.</p>
        )}
        {product.stock === 0 && <p className="mt-4 font-mono text-xs text-danger">Épuisé.</p>}

        <section className="mt-20 border-t border-line pt-10">
          <h2 className="font-display italic text-2xl mb-8 text-paper">Avis clients</h2>

          <div className="space-y-6 mb-12">
            {product.reviews.map((r) => (
              <div key={r.id} className="border-b border-line pb-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-paper">{r.author}</span>
                  <ReviewStars rating={r.rating} size={14} />
                </div>
                <p className="text-sm text-paper/80">{r.comment}</p>
              </div>
            ))}
            {product.reviews.length === 0 && (
              <p className="text-sm text-brass">Soyez le premier à donner votre avis.</p>
            )}
          </div>

          <ReviewForm productId={product.id} />
        </section>
      </div>
    </div>
  );
}
