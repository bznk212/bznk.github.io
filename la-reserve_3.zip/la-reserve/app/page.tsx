import { prisma } from "@/lib/prisma";
import ProductCard from "@/components/shop/ProductCard";
import Link from "next/link";

export default async function HomePage() {
  const featured = await prisma.product.findMany({
    where: { isFeatured: true },
    include: { images: { orderBy: { position: "asc" }, take: 1 } },
    orderBy: { createdAt: "desc" },
    take: 4,
  });

  const count = await prisma.product.count();

  return (
    <>
      {/* HERO — asymétrique, la vitrine se dévoile de gauche à droite */}
      <section className="relative border-b border-line overflow-hidden">
        <div className="max-w-[1400px] mx-auto px-6 md:px-16 grid md:grid-cols-12 gap-8 py-20 md:py-32">
          <div className="md:col-span-7 md:col-start-1 flex flex-col justify-center">
            <p className="eyebrow mb-8">
              Registre N° {String(count).padStart(4, "0")} — Collection ouverte
            </p>
            <h1 className="font-display italic text-5xl md:text-[5.5rem] leading-[0.98] text-paper overflow-hidden">
              <span className="block animate-unveil">Rien n'entre</span>
              <span className="block animate-unveil [animation-delay:150ms]">ici sans</span>
              <span className="block animate-unveil [animation-delay:300ms]">
                être <span className="text-brass">rare.</span>
              </span>
            </h1>
            <p className="mt-10 text-paper-dim max-w-md leading-relaxed animate-fade-up [animation-delay:700ms] opacity-0">
              Chaque pièce de La Reserve porte un numéro. Aucune n'est réimprimée, aucune n'est
              rééditée — la rareté est le seul critère d'entrée dans ce registre.
            </p>
            <div className="mt-12 animate-fade-up [animation-delay:900ms] opacity-0">
              <Link href="/produits" className="btn-reserve">
                Consulter le registre
              </Link>
            </div>
          </div>

          <div className="md:col-span-4 md:col-start-9 flex items-end">
            <div className="w-full border border-line-strong p-6 font-mono text-[11px] text-paper-dim tracking-wide2 uppercase space-y-3">
              <div className="flex justify-between border-b border-line pb-3">
                <span>Pièces au registre</span>
                <span className="text-brass">{String(count).padStart(3, "0")}</span>
              </div>
              <div className="flex justify-between border-b border-line pb-3">
                <span>Réédition</span>
                <span className="text-brass">Jamais</span>
              </div>
              <div className="flex justify-between">
                <span>Provenance</span>
                <span className="text-brass">Vérifiée</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* PIÈCES RARES — index du catalogue */}
      <section className="section">
        <div className="flex items-baseline justify-between mb-16 border-b border-line pb-6">
          <h2 className="font-display italic text-3xl text-paper">Dernières entrées</h2>
          <Link href="/produits" className="eyebrow hover:text-paper transition-colors">
            Registre complet →
          </Link>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-x-8 gap-y-16">
          {featured.map((p, i) => (
            <ProductCard
              key={p.id}
              index={i + 1}
              slug={p.slug}
              title={p.title}
              price={Number(p.price)}
              image={p.images[0]?.url ?? "/uploads/placeholder-1.jpg"}
              stock={p.stock}
            />
          ))}
        </div>

        {featured.length === 0 && (
          <p className="text-paper-dim font-mono text-sm">
            Le registre des pièces rares est vide pour le moment.
          </p>
        )}
      </section>
    </>
  );
}
