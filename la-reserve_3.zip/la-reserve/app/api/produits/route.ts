import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { z } from "zod";

const productSchema = z.object({
  title: z.string().min(2),
  slug: z.string().min(2),
  description: z.string().min(10),
  price: z.number().positive(),
  stock: z.number().int().nonnegative(),
  brand: z.string().optional(),
  category: z.string().optional(),
  isFeatured: z.boolean().optional(),
  images: z.array(z.string().url()).min(1),
});

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const category = searchParams.get("category") ?? undefined;
  const featured = searchParams.get("featured");

  const products = await prisma.product.findMany({
    where: {
      category: category || undefined,
      isFeatured: featured === "true" ? true : undefined,
    },
    include: {
      images: { orderBy: { position: "asc" } },
      reviews: true,
    },
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json(products);
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const parsed = productSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const { images, ...data } = parsed.data;

  const product = await prisma.product.create({
    data: {
      ...data,
      images: {
        create: images.map((url, position) => ({ url, position })),
      },
    },
    include: { images: true },
  });

  return NextResponse.json(product, { status: 201 });
}
