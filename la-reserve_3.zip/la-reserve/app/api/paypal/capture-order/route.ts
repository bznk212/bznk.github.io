import { NextRequest, NextResponse } from "next/server";
import { capturePayPalOrder } from "@/lib/paypal";
import { prisma } from "@/lib/prisma";

export async function POST(req: NextRequest) {
  const { paypalOrderId } = await req.json();
  if (!paypalOrderId) {
    return NextResponse.json({ error: "paypalOrderId manquant" }, { status: 400 });
  }

  const capture = await capturePayPalOrder(paypalOrderId);

  if (capture.status !== "COMPLETED") {
    return NextResponse.json({ error: "Paiement non complété" }, { status: 400 });
  }

  // Le paiement est confirmé : PayPal a transféré les fonds sur le compte
  // marchand configuré dans PAYPAL_CLIENT_ID / PAYPAL_CLIENT_SECRET.
  const order = await prisma.order.update({
    where: { paypalOrderId },
    data: { status: "PAID" },
  });

  // Décrémenter le stock des produits achetés.
  const items = await prisma.orderItem.findMany({ where: { orderId: order.id } });
  await Promise.all(
    items.map((item) =>
      prisma.product.update({
        where: { id: item.productId },
        data: { stock: { decrement: item.quantity } },
      })
    )
  );

  return NextResponse.json({ success: true, orderId: order.id });
}
