import { NextRequest, NextResponse } from "next/server";
import { createPayPalOrder } from "@/lib/paypal";
import { prisma } from "@/lib/prisma";

export async function POST(req: NextRequest) {
  const { cart, customer } = await req.json();
  // cart: [{ productId, quantity }]
  // customer: { name, email, address, city, postalCode, country }

  if (!cart?.length) {
    return NextResponse.json({ error: "Panier vide" }, { status: 400 });
  }

  const products = await prisma.product.findMany({
    where: { id: { in: cart.map((c: any) => c.productId) } },
  });

  const items = cart.map((c: any) => {
    const product = products.find((p) => p.id === c.productId)!;
    return { title: product.title, price: Number(product.price), quantity: c.quantity };
  });

  const total = items.reduce((sum, i) => sum + i.price * i.quantity, 0);

  const paypalOrder = await createPayPalOrder(items, total);

  // On crée la commande en base au statut PENDING, on la mettra à PAID à la capture.
  const order = await prisma.order.create({
    data: {
      customerName: customer.name,
      customerEmail: customer.email,
      address: customer.address,
      city: customer.city,
      postalCode: customer.postalCode,
      country: customer.country,
      total,
      paypalOrderId: paypalOrder.id,
      items: {
        create: cart.map((c: any) => {
          const product = products.find((p) => p.id === c.productId)!;
          return { productId: c.productId, quantity: c.quantity, price: product.price };
        }),
      },
    },
  });

  return NextResponse.json({ paypalOrderId: paypalOrder.id, orderId: order.id });
}
