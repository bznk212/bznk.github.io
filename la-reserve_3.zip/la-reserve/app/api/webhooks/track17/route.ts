import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

// À configurer dans le dashboard 17track : Settings > Webhook
// URL à renseigner : https://tondomaine.com/api/webhooks/track17
export async function POST(req: NextRequest) {
  const payload = await req.json();

  if (payload?.event !== "TRACKING_UPDATED") {
    return NextResponse.json({ received: true });
  }

  const accepted = payload?.data?.accepted ?? [];

  for (const item of accepted) {
    const trackingNumber = item.number;
    const status = item.track_info?.latest_status?.status; // ex: "InTransit", "Delivered", "OutForDelivery"

    if (!trackingNumber) continue;

    const order = await prisma.order.findFirst({ where: { trackingNumber } });
    if (!order) continue;

    if (status === "Delivered") {
      await prisma.order.update({ where: { id: order.id }, data: { status: "DELIVERED" } });
    } else if (status === "InTransit" || status === "OutForDelivery" || status === "InfoReceived") {
      await prisma.order.update({ where: { id: order.id }, data: { status: "SHIPPED" } });
    }
  }

  return NextResponse.json({ received: true });
}
