import { NextRequest, NextResponse } from "next/server";
import { getTrackInfo } from "@/lib/track17";
import { prisma } from "@/lib/prisma";

export async function GET(req: NextRequest, { params }: { params: { trackingNumber: string } }) {
  const order = await prisma.order.findFirst({
    where: { trackingNumber: params.trackingNumber },
  });

  if (!order) {
    return NextResponse.json({ error: "Commande introuvable pour ce numéro de suivi" }, { status: 404 });
  }

  const carrierCode = order.carrier ? Number(order.carrier) : undefined;
  const tracking = await getTrackInfo(params.trackingNumber, carrierCode);
  return NextResponse.json(tracking);
}
