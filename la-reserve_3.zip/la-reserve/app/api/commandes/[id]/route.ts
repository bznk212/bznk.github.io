import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { createTracking } from "@/lib/track17";

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  const order = await prisma.order.findUnique({
    where: { id: params.id },
    include: { items: { include: { product: true } } },
  });
  if (!order) return NextResponse.json({ error: "Commande introuvable" }, { status: 404 });
  return NextResponse.json(order);
}

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  const body = await req.json();
  const { trackingNumber, carrier, status } = body;

  // Si on ajoute un numéro de suivi pour la première fois, on l'enregistre
  // aussi auprès de 17track pour recevoir les mises à jour automatiques.
  // Le code transporteur est optionnel : 17track auto-détecte la plupart des cas.
  if (trackingNumber) {
    try {
      await createTracking(trackingNumber, carrier ? Number(carrier) : undefined);
    } catch (e) {
      // On n'empêche pas la sauvegarde en base si 17track refuse le format,
      // l'admin peut corriger le numéro ensuite.
      console.error("Erreur 17track:", e);
    }
  }

  const order = await prisma.order.update({
    where: { id: params.id },
    data: {
      trackingNumber,
      carrier,
      status: status || undefined,
    },
  });

  return NextResponse.json(order);
}
