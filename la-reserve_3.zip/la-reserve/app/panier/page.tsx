"use client";

import { useCart } from "@/context/CartContext";
import Link from "next/link";
import Image from "next/image";

export default function CartPage() {
  const { items, removeItem, updateQuantity, total } = useCart();

  if (items.length === 0) {
    return (
      <div className="section text-center">
        <h1 className="font-display italic text-3xl mb-6">Votre panier est vide</h1>
        <Link href="/produits" className="btn-reserve-outline">
          Voir la collection
        </Link>
      </div>
    );
  }

  return (
    <div className="section">
      <h1 className="font-display italic text-3xl mb-12">Votre panier</h1>

      <div className="space-y-8">
        {items.map((item) => (
          <div key={item.productId} className="flex gap-6 border-b border-line pb-8">
            <div className="relative w-24 aspect-[4/5] bg-panel shrink-0">
              {item.image && <Image src={item.image} alt={item.title} fill className="object-cover" />}
            </div>
            <div className="flex-1 flex flex-col justify-between">
              <div className="flex justify-between">
                <h3 className="font-display italic text-lg">{item.title}</h3>
                <span>{(item.price * item.quantity).toFixed(2)} €</span>
              </div>
              <div className="flex items-center gap-4">
                <input
                  type="number"
                  min={1}
                  value={item.quantity}
                  onChange={(e) => updateQuantity(item.productId, Number(e.target.value))}
                  className="w-16 border border-line px-2 py-1 bg-transparent text-paper focus:outline-none focus:border-brass"
                />
                <button
                  onClick={() => removeItem(item.productId)}
                  className="text-xs uppercase tracking-wide2 text-brass underline"
                >
                  Retirer
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-12 flex justify-between items-center">
        <span className="font-display italic text-2xl">Total : {total.toFixed(2)} €</span>
        <Link href="/checkout" className="btn-reserve">
          Passer au paiement
        </Link>
      </div>
    </div>
  );
}
