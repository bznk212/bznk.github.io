import Link from "next/link";

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen">
      <aside className="w-64 border-r border-line p-8 hidden md:block">
        <h2 className="font-display text-xl mb-10">La Reserve</h2>
        <nav className="space-y-4 text-sm uppercase tracking-wide2">
          <Link href="/admin/dashboard" className="block">
            Tableau de bord
          </Link>
          <Link href="/admin/produits" className="block">
            Produits
          </Link>
          <Link href="/admin/commandes" className="block">
            Commandes
          </Link>
        </nav>
      </aside>
      <div className="flex-1 p-8 md:p-12">{children}</div>
    </div>
  );
}
