import { prisma } from "@/lib/prisma";
import StatsCards from "@/components/admin/StatsCards";

export default async function DashboardPage() {
  const [orders, expenses] = await Promise.all([
    prisma.order.findMany({ where: { status: { not: "CANCELLED" } } }),
    prisma.expense.findMany(),
  ]);

  const sales = orders.reduce((sum, o) => sum + Number(o.total), 0);
  const totalExpenses = expenses.reduce((sum, e) => sum + Number(e.amount), 0);
  const profit = sales - totalExpenses;

  const recentOrders = [...orders]
    .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
    .slice(0, 8);

  return (
    <div>
      <h1 className="font-display text-3xl mb-10">Tableau de bord</h1>

      <StatsCards sales={sales} expenses={totalExpenses} profit={profit} ordersCount={orders.length} />

      <div className="mt-12">
        <h2 className="font-display text-xl mb-6">Commandes récentes</h2>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left eyebrow border-b border-line">
              <th className="py-3">Client</th>
              <th>Total</th>
              <th>Statut</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            {recentOrders.map((o) => (
              <tr key={o.id} className="border-b border-line">
                <td className="py-3">{o.customerName}</td>
                <td>{Number(o.total).toFixed(2)} €</td>
                <td>{o.status}</td>
                <td>{o.createdAt.toLocaleDateString("fr-FR")}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
