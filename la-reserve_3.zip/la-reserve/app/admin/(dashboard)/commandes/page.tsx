import { prisma } from "@/lib/prisma";
import OrderRow from "@/components/admin/OrderRow";

export default async function AdminOrdersPage() {
  const orders = await prisma.order.findMany({ orderBy: { createdAt: "desc" } });

  return (
    <div>
      <h1 className="font-display text-3xl mb-10">Commandes</h1>

      <table className="w-full text-sm">
        <thead>
          <tr className="text-left eyebrow border-b border-line">
            <th className="py-3">Client</th>
            <th>Total</th>
            <th>Statut</th>
            <th>Transporteur</th>
            <th>N° de suivi</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {orders.map((o) => (
            <OrderRow
              key={o.id}
              order={{
                id: o.id,
                customerName: o.customerName,
                total: Number(o.total),
                status: o.status,
                trackingNumber: o.trackingNumber,
                carrier: o.carrier,
                createdAt: o.createdAt.toISOString(),
              }}
            />
          ))}
        </tbody>
      </table>

      {orders.length === 0 && <p className="text-brass mt-6">Aucune commande pour le moment.</p>}
    </div>
  );
}
