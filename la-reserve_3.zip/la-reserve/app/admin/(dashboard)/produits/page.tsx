import { prisma } from "@/lib/prisma";
import Link from "next/link";
import DeleteProductButton from "@/components/admin/DeleteProductButton";

export default async function AdminProductsPage() {
  const products = await prisma.product.findMany({
    include: { images: { take: 1 } },
    orderBy: { createdAt: "desc" },
  });

  return (
    <div>
      <div className="flex justify-between items-center mb-10">
        <h1 className="font-display text-3xl">Produits</h1>
        <Link href="/admin/produits/nouveau" className="btn-reserve">
          + Ajouter un produit
        </Link>
      </div>

      <table className="w-full text-sm">
        <thead>
          <tr className="text-left eyebrow border-b border-line">
            <th className="py-3">Titre</th>
            <th>Prix</th>
            <th>Stock</th>
            <th>Catégorie</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {products.map((p) => (
            <tr key={p.id} className="border-b border-line">
              <td className="py-3">{p.title}</td>
              <td>{Number(p.price).toFixed(2)} €</td>
              <td>{p.stock}</td>
              <td>{p.category ?? "—"}</td>
              <td className="text-right space-x-4">
                <Link href={`/admin/produits/${p.id}/edit`} className="underline text-brass">
                  Modifier
                </Link>
                <DeleteProductButton productId={p.id} />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
