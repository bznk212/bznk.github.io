import ProductForm from "@/components/admin/ProductForm";

export default function NewProductPage() {
  return (
    <div>
      <h1 className="font-display text-3xl mb-10">Nouveau produit</h1>
      <ProductForm />
    </div>
  );
}
