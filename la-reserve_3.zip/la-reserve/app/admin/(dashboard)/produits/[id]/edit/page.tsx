import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import ProductForm from "@/components/admin/ProductForm";

export default async function EditProductPage({ params }: { params: { id: string } }) {
  const product = await prisma.product.findUnique({
    where: { id: params.id },
    include: { images: { orderBy: { position: "asc" } } },
  });

  if (!product) notFound();

  return (
    <div>
      <h1 className="font-display text-3xl mb-10">Modifier {product.title}</h1>
      <ProductForm
        initial={{
          id: product.id,
          title: product.title,
          slug: product.slug,
          description: product.description,
          price: Number(product.price),
          stock: product.stock,
          brand: product.brand ?? "",
          category: product.category ?? "",
          isFeatured: product.isFeatured,
          images: product.images.map((i) => i.url),
        }}
      />
    </div>
  );
}
