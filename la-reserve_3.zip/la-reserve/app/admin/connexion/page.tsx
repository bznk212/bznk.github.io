"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";

export default function AdminLoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const router = useRouter();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    const res = await signIn("credentials", { email, password, redirect: false });
    if (res?.error) {
      setError("Identifiants incorrects.");
    } else {
      router.push("/admin/dashboard");
    }
  }

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-6">
      <form onSubmit={handleSubmit} className="w-full max-w-sm space-y-6">
        <h1 className="font-display text-3xl text-center mb-4">La Reserve — Admin</h1>
        <div>
          <label className="eyebrow block mb-2">Email</label>
          <input
            required
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full border border-line px-4 py-2 bg-transparent text-paper placeholder:text-paper-dim focus:outline-none focus:border-brass"
          />
        </div>
        <div>
          <label className="eyebrow block mb-2">Mot de passe</label>
          <input
            required
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full border border-line px-4 py-2 bg-transparent text-paper placeholder:text-paper-dim focus:outline-none focus:border-brass"
          />
        </div>
        {error && <p className="text-sm text-danger">{error}</p>}
        <button type="submit" className="btn-reserve w-full">
          Se connecter
        </button>
      </form>
    </div>
  );
}
