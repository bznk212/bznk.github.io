import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        ink: "#14120F",       // fond principal — noir chaud, chambre forte
        paper: "#F2EDE4",     // texte principal — papier/os
        "paper-dim": "rgba(242,237,228,0.55)",
        brass: "#B08D57",     // accent métallique — laiton, sobre et rare
        oxblood: "#6B1E23",   // accent secondaire — cire, tampon d'archive
        danger: "#C4574F",    // erreurs — lisible sur fond sombre
        panel: "rgba(242,237,228,0.05)", // fond subtil pour cartes/placeholders
        line: "rgba(242,237,228,0.14)",
        "line-strong": "rgba(242,237,228,0.28)",
      },
      fontFamily: {
        display: ["var(--font-display)", "serif"],
        body: ["var(--font-body)", "sans-serif"],
        mono: ["var(--font-mono)", "monospace"],
      },
      letterSpacing: {
        wide2: "0.14em",
        wide3: "0.28em",
      },
      transitionTimingFunction: {
        "reserve-ease": "cubic-bezier(0.22, 1, 0.36, 1)",
      },
      keyframes: {
        unveil: {
          "0%": { clipPath: "inset(0 100% 0 0)" },
          "100%": { clipPath: "inset(0 0 0 0)" },
        },
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(14px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
      },
      animation: {
        unveil: "unveil 1.1s cubic-bezier(0.22,1,0.36,1) forwards",
        "fade-up": "fade-up 0.8s cubic-bezier(0.22,1,0.36,1) forwards",
      },
    },
  },
  plugins: [require("@tailwindcss/typography")],
};
export default config;

