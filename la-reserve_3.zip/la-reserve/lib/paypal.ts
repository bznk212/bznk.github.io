// Wrapper léger autour de l'API REST PayPal (v2/checkout/orders)
// On évite le SDK officiel côté build Next.js et on utilise fetch directement,
// ce qui est plus fiable en environnement serverless (Vercel).

const PAYPAL_BASE_URL =
  process.env.PAYPAL_ENV === "live"
    ? "https://api-m.paypal.com"
    : "https://api-m.sandbox.paypal.com";

async function getAccessToken() {
  const clientId = process.env.PAYPAL_CLIENT_ID!;
  const secret = process.env.PAYPAL_CLIENT_SECRET!;
  const auth = Buffer.from(`${clientId}:${secret}`).toString("base64");

  const res = await fetch(`${PAYPAL_BASE_URL}/v1/oauth2/token`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${auth}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: "grant_type=client_credentials",
    cache: "no-store",
  });

  if (!res.ok) throw new Error("Impossible d'obtenir un token PayPal");
  const data = await res.json();
  return data.access_token as string;
}

export async function createPayPalOrder(items: { title: string; price: number; quantity: number }[], total: number) {
  const accessToken = await getAccessToken();

  const res = await fetch(`${PAYPAL_BASE_URL}/v2/checkout/orders`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      intent: "CAPTURE",
      purchase_units: [
        {
          amount: {
            currency_code: "EUR",
            value: total.toFixed(2),
            breakdown: {
              item_total: { currency_code: "EUR", value: total.toFixed(2) },
            },
          },
          items: items.map((i) => ({
            name: i.title.substring(0, 127),
            unit_amount: { currency_code: "EUR", value: i.price.toFixed(2) },
            quantity: String(i.quantity),
          })),
        },
      ],
    }),
    cache: "no-store",
  });

  if (!res.ok) throw new Error("Échec de création de la commande PayPal");
  return res.json();
}

export async function capturePayPalOrder(paypalOrderId: string) {
  const accessToken = await getAccessToken();

  const res = await fetch(`${PAYPAL_BASE_URL}/v2/checkout/orders/${paypalOrderId}/capture`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    cache: "no-store",
  });

  if (!res.ok) throw new Error("Échec de la capture du paiement PayPal");
  return res.json();
}
