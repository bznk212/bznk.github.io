const TRACK17_BASE_URL = "https://api.17track.net/track/v2.4";

function headers() {
  return {
    "17token": process.env.TRACK17_API_KEY!,
    "Content-Type": "application/json",
  };
}

// Enregistre un numéro de suivi. Le code transporteur (carrier) est optionnel :
// 17track auto-détecte plus de 80% des transporteurs à partir du format du numéro.
// Si tu connais le code exact, trouve-le sur https://res.17track.net/asset/carrier/info/carrier.all.json
export async function createTracking(trackingNumber: string, carrierCode?: number) {
  const payload = carrierCode
    ? [{ number: trackingNumber, carrier: carrierCode }]
    : [{ number: trackingNumber }];

  const res = await fetch(`${TRACK17_BASE_URL}/register`, {
    method: "POST",
    headers: headers(),
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error("Échec de l'enregistrement du suivi 17track");
  return res.json();
}

export async function getTrackInfo(trackingNumber: string, carrierCode?: number) {
  const payload = carrierCode
    ? [{ number: trackingNumber, carrier: carrierCode }]
    : [{ number: trackingNumber }];

  const res = await fetch(`${TRACK17_BASE_URL}/gettrackinfo`, {
    method: "POST",
    headers: headers(),
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error("Échec de récupération du suivi 17track");
  return res.json();
}
